create view vw_account as
  select `company`.`employees`.`emp_no`     AS `emp_no`,
         `company`.`employees`.`birth_date` AS `birth_date`,
         `company`.`employees`.`first_name` AS `first_name`,
         `company`.`employees`.`last_name`  AS `last_name`,
         `company`.`employees`.`gender`     AS `gender`,
         `company`.`employees`.`hire_date`  AS `hire_date`,
         `company`.`employees`.`dno`        AS `dno`
  from `company`.`employees`;

